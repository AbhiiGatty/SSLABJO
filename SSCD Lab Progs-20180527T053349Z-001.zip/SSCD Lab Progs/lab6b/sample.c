#inlcude<stdio.h>
int main()
{
	int a,b;
	a=1;
	b=5;
	a=a+b*5;
	printf("A= %d B= %d",a,b);
	return 0;
}
