#include<stdio.h>
main()
{
	int a=4,b=6;
	a=b+5*a;
	printf("Hello There");
	return;
}
