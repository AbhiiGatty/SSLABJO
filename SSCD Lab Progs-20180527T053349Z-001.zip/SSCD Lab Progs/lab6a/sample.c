/*Cooment*/ 
//there
#include<stdio.h>
main()
{
	printf("Hi /*Hello */ there");
}
