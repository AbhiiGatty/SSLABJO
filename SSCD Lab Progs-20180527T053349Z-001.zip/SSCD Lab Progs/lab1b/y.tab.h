#define NUM 257
#define UMINUS 258
typedef union{double dval;} YYSTYPE;
extern YYSTYPE yylval;
